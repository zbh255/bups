from  DelFileFont import DelFile
from tkinter import Button,Text,getboolean