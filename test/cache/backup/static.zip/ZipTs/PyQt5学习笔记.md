#PyQt5学习笔记
---
#关于PyQt5
PyQt5 是Digia的一套Qt5与python绑定的应用框架，同时支持2.x和3.x。本教程使用的是3.x。Qt库由Riverbank Computing开发，是最强大的GUI库之一 ，官方网站：www.riverbankcomputing.co.uk/news。

PyQt5是由一系列Python模块组成。超过620个类，6000和函数和方法。能在诸如Unix、Windows和Mac OS等主流操作系统上运行。PyQt5有两种证书，GPL和商业证书。

PyQt5类分为很多模块，主要模块有：
```java
QtCore 包含了核心的非GUI的功能。主要和时间、文件与文件夹、各种数据、流、URLs、mime类文件、进程与线程一起使用。
QtGui 包含了窗口系统、事件处理、2D图像、基本绘画、字体和文字类。
QtWidgets
QtMultimedia
QtBluetooth
QtNetwork
QtPositioning
Enginio
QtWebSockets
QtWebKit
QtWebKitWidgets
QtXml
QtSvg
QtSql
QtTest
QtWidgets类包含了一系列创建桌面应用的UI元素。
QtMultimedia包含了处理多媒体的内容和调用摄像头API的类。
QtBluetooth模块包含了查找和连接蓝牙的类。
QtNetwork包含了网络编程的类，这些工具能让TCP/IP和UDP开发变得更加方便和可靠。
QtPositioning包含了定位的类，可以使用卫星、WiFi甚至文本。
Engine包含了通过客户端进入和管理Qt Cloud的类。
QtWebSockets包含了WebSocket协议的类。
QtWebKit包含了一个基WebKit2的web浏览器。
QtWebKitWidgets包含了基于QtWidgets的WebKit1的类。
QtXml包含了处理xml的类，提供了SAX和DOM API的工具。
QtSvg提供了显示SVG内容的类，Scalable Vector Graphics (SVG)是一种是一种基于可扩展标记语言（XML），用于描述二维矢量图形的图形格式（这句话来自于维基百科）。
QtSql提供了处理数据库的工具。
QtTest提供了测试PyQt5应用的工具。
```
---
#PyQt5入门-"Hello word"案例
>一个简单的小窗口:
```python {.line-numbers}
import sys
from PyQt5.QtWidgets import QApplication, QWidget
if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = QWidget()
    w.resize(250, 150)
    w.move(300, 300)
    w.setWindowTitle('Simple')
    w.show()
    sys.exit(app.exec_())
```
上面的代码运行之后会显示一个小窗口。

接下来我们解析每一行代码的意思：
---

```python {.line-numbers}
import sys
from PyQt5.QtWidgets import QApplication, QWidget
```
在这段代码中，引入了PyQt5.Widgets模块，这个模块包含了基本的组件。
```cpp {.line-numbers}
app = QApplication(sys.argv)
```
每个`PyQt5`应用都必须创建一个应用对象。`sys.argv`是一组命令行参数的列表。Python可以在shell里运行，这个参数提供对脚本控制的功能,`sys.argv`可以让程序接收外部参数。
```python {.line-numbers}
w = QWidget()
```
QWidgett控件是一个用户界面的基本控件，它提供了基本的应用构造器，构造器默认是没有父级的，没有父级的构造器被称为窗口（window）。
```python {.line-numbers}
w.resize(250, 150)
```
使用`resize()`方法改变控件的大小，这里的意思是窗口宽250px，高150px
```python {.line-numbers}
w.move(300, 300)
```
使用`move()`方法能修改控件的位置，这行代码将控件放置到屏幕坐标的（300,300）位置。`注意：屏幕坐标的原点从屏幕的左上角开始`
```python {.line-numbers}
w.setWindowTitle('Simple')
```
使用`setWindowTitle()`方法为窗口添加一个标题，窗口的标题在标题栏里展示
```python {.line-numbers}
w.show()
```
show()方法能让控件在桌面上显示出来。控件先是在内存里创建，之后才能在显示器上显示出来。
```python {.line-mumbers}
sys.exit(app.exec_())
```
最后，我们进入了应用的主循环中，事件处理器这个时候开始工作。主循环从窗口上接收事件，并把事件传入到派发到应用控件里。当调用exit()方法或直接销毁主控件时，主循环就会结束。sys.exit()方法能确保主循环安全退出。外部环境能通知主控件怎么结束。exec_()之所以有个下划线，是因为exec是一个Python的关键字。

---
##PyQt5小例子-消息盒子
```python {.line-numbers}
import sys
from PyQt5.QtWidgets import QWidget, QMessageBox, QApplication
class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):               
        self.setGeometry(300, 300, 250, 150)        
        self.setWindowTitle('Message box')    
        self.show()
    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Message',
            "Are you sure to quit?", QMessageBox.Yes | 
            QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()        
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())
```
当关闭`QWidget`的时候程序会产生一个<font color=green>QCloseEvent</font>对象。改变控件的默认行为，就是替换掉默认的事件处理

```python {.line-numbers}
def closeEvent(self, event):
    reply = QMessageBox.question(self, 'Message',
        "Are you sure to quit?", QMessageBox.Yes | 
        QMessageBox.No, QMessageBox.No)
    if reply == QMessageBox.Yes:
        event.accept()
    else:
        event.ignore()        
```
> 定义第二个函数时，我们需要一个形参来接收传进来的`QCloseEvent`对象，我把形参命名为event

> 在代码的第二行，我们创建了一个消息框，我创建了两个按钮：Yes和No，第一个字符串会显示在消息框的标题栏，第二个字符串则是消息框的文本，第三个参数是消息框的两个按钮，第四个参数定义了默认选中的按钮。最后将返回值存储在变量`reply`中

>代码的第五行判断返回值，如果是Yes就关闭程序，如果是No就继续执行程序

---
#PyQt5入门-菜单和工具栏
###主窗口：

---
<code>QMainWindow</code>提供了主窗口的功能，使用它能创建一些简单的状态栏、工具栏和菜单栏，主窗口是下面这些窗口的合称。

###状态栏

---
状态栏是用来显示应用的状态信息的组件
```python{.line-numbers}
import sys
from PyQt5.QtWidgets import QMainWindow, QApplication


class Example(QMainWindow):

    def __init__(self):
        super().__init__()

        self.initUI()


    def initUI(self):               

        self.statusBar().showMessage('Ready')

        self.setGeometry(300, 300, 250, 150)
        self.setWindowTitle('Statusbar')    
        self.show()


if __name__ == '__main__':

    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())
```
> 状态栏是由QMainWindow创建的。创建状态栏时调用QMainWindow的statusBar方法

    self.statusBar().showMessage('Ready')
调用```QtGui.QMainWindow```类的```statusBar()```方法，创建状态栏。第一次调用创建一个状态栏，返回一个状态栏对象。```showMessage()```方法在状态栏上显示一条信息。

```java
记录一点坑：
    PyQt5的方法命名很奇怪，写的时候一定要注意！
    比如：设置窗口标题的方法名叫（setWindowTitle）有时候会写成（WindowTitle）
    PyQt5虽然功能强大，但是方法命名有点不明确，和WxPython比较的话
    PyQt5的很多方法都有一个set，书写的时候要注意！
```

###菜单栏
---

>菜单栏是非常常用的。是一组命令的集合

```python {.line-numbers}
import sys
from PyQt5.QtWidgets import QMainWindow, QAction, qApp, QApplication
from PyQt5.QtGui import QIcon


class Example(QMainWindow):

    def __init__(self):
        super().__init__()

        self.initUI()


    def initUI(self):               

        exitAct = QAction(QIcon('exit.png'), '&Exit', self)        
        exitAct.setShortcut('Ctrl+Q')
        exitAct.setStatusTip('Exit application')
        exitAct.triggered.connect(qApp.quit)

        self.statusBar()

        menubar = self.menuBar()
        fileMenu = menubar.addMenu('&File')
        fileMenu.addAction(exitAct)

        self.setGeometry(300, 300, 300, 200)
        self.setWindowTitle('Simple menu')    
        self.show()


if __name__ == '__main__':

    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())
```

[TOC]

# 标题1
## 标题2 {ignore=true}
标题2 将会被目录忽略.